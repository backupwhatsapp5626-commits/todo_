// Paste auth.ts code from canvas
