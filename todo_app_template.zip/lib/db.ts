// Paste db.ts code from canvas
