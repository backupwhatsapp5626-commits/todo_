// Paste LoginWallet code from canvas
