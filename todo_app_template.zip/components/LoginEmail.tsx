// Paste LoginEmail code from canvas
