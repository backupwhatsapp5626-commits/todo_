Paste the code from the ChatGPT canvas into the correct files.
