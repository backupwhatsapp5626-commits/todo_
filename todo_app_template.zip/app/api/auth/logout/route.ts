// Paste logout API code from canvas
