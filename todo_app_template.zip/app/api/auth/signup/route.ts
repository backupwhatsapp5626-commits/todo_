// Paste signup API code from canvas
