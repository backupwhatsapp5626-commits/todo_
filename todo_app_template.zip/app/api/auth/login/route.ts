// Paste login API code from canvas
