// Paste home page code from canvas
