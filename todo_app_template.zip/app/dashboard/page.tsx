// Paste dashboard page code from canvas
