// Paste tailwind config from canvas
